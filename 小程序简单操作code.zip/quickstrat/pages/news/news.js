// pages/news/news.js
var app=getApp();
var com=require('../../utils/common');
Page({
  data:{
    msg:"欢迎观临我的小程序~"
  },
  changeMsg(){
    this.setData({
      msg:app.b
    })
  },
  fnUserState(){
    this.setData({
      msg:com.echoHello('Strive')
    });
  },
  fnUserState2(){
    this.setData({
      msg:com.echoBye('blue')
    });
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady:function(){
    // 页面渲染完成
    console.log(com);
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})