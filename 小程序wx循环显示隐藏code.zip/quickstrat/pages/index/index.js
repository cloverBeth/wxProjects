//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    motto: 'welcome wx',
    userInfo: {},
    bShow:false,
    msg:'我隐藏了',
    arr:['apple','orange','pear'],
    arrData:[
      {name:"apple",age:10},
      {name:"orange",age:11},
      {name:"pear",age:12},
      ]
  },
  change(){
    this.setData({
      bShow:!this.data.bShow,
      msg:'可爱的我又出现了！'
    
    });
  },
  changeMotto(){
    this.setData({
      motto:'great:'+Date.now()
    })
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    console.log('onLoad')
    var that = this
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function(userInfo){
      //更新数据
      that.setData({
        userInfo:userInfo
      })
    })
  }
})
