// pages/search/search.js
var API_URL="https://api.douban.com/v2/movie/search";
Page({
  data:{
    movies:[]
  },
  search:function(e){
    if(!e.detail.value){
      return;
    }
    wx.showToast({
      titile:"加载中...",
      icon:"loading",
      duration:10000
    });
    var that=this;
    wx.request({
      url: API_URL+"?q="+e.detail.value,
      data: {},
      header: {
        'Content-Type':'json'
      }, // 设置请求的 header
      success: function(res){
        // success
        wx.hideToast();
        that.setData({
          movies:res.data.subjects
        })
      }
    });
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  }
})