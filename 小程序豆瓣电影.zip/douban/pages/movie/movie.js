// pages/movie/movie.js
var API_URL="https://api.douban.com/v2/movie/subject/";
Page({
  data:{

  },
  onLoad:function(params){
    // 页面初始化 options为页面跳转所带来的参数
    var that=this;
     wx.request({
      url: API_URL+params.id,
      data: {},
      header: {
        'Content-Type':'json'
      }, // 设置请求的 header
      success: function(res){
        // success
        console.log(res.data);
        that.setData({
          movie:res.data
        });
      }
    })
  }
})